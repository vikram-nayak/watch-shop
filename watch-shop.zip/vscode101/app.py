from flask import Flask, request, jsonify, render_template

app = Flask(__name__)

# Dummy database for demonstration
users = {"user@example.com": "password123"}
cart = []
wishlist = []

@app.route('/')
def watch-shop():
    return render_template('watch-shop.html')  # Ensure 'index.html' is in the 'templates' folder

@app.route('/login', methods=['POST'])
def login():
    email = request.form['email']
    password = request.form['password']

    if email in users and users[email] == password:
        return jsonify({"message": "Login successful!"}), 200
    else:
        return jsonify({"message": "Invalid credentials"}), 401

@app.route('/add_to_cart', methods=['POST'])
def add_to_cart():
    data = request.get_json()
    item = data['item']
    price = data['price']
    cart.append({'item': item, 'price': price})
    return jsonify({"message": f"{item} added to cart.", "cart": cart}), 200

@app.route('/add_to_wishlist', methods=['POST'])
def add_to_wishlist():
    data = request.get_json()
    item = data['item']
    wishlist.append(item)
    return jsonify({"message": f"{item} added to wishlist.", "wishlist": wishlist}), 200

if __name__ == '__main__':
    app.run(debug=True)
